package com.example.ac2.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class TreinamentoDTO {
  private Integer id;
  private String treinamento;
}
