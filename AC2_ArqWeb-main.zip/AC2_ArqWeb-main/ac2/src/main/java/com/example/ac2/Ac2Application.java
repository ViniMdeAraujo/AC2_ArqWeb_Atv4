package com.example.ac2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ac2Application {

	public static void main(String[] args) {
		SpringApplication.run(Ac2Application.class, args);
	}

}
